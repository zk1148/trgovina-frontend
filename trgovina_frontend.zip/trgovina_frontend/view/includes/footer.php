<footer>
    <div class="panel-footer noga">
        FRI 2016/2017
    </div>
</footer>


<!-- Metis Menu Plugin JavaScript -->
<script src="static/js/jquery.js"></script>
<script src="static/js/trgovina.js"></script>
<script src="static/js/jquery.toast.min.js"></script>
<script src="static/metisMenu/dist/metisMenu.min.js"></script>

<!-- Custom Theme JavaScript -->
<script src="static/js/sb-admin-2.js"></script>

<script src="static/js/bootstrap.js"></script>