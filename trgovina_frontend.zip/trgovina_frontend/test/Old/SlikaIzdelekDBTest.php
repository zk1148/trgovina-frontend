<?php
require 'model/SlikaIzdelkaDB.php';

//SlikaIzdelkaDB::insert(
//    [
//        "idIzdelek" => "1", "slika" => "pot do slike1"
//    ]
//);

//SlikaIzdelkaDB::update(
//    [
//        "idSlikaIzdelka" => "1", "idIzdelek" => "1", "slika" => "pot do slike2"
//    ]
//);

//SlikaIzdelkaDB::delete(
//    [
//        "idSlikaIzdelka" => "1"
//    ]
//);

//SlikaIzdelkaDB::get(
//    [
//        "idSlikaIzdelka" => "2"
//    ]
//);

SlikaIzdelkaDB::getAll();
