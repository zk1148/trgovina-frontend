<?php
require 'model/NarociloDB.php';

//NarociloDB::insert(
//    [
//        "cenaSkupaj" => "50.89", "status" => "1", "idStranke" => "1"
//    ]
//);

//NarociloDB::update(
//    [
//        "idNarocilo" => "1", "status" => "2", "idProdajalca" => "1", "datumPotrditve" => "2015-12-15 15:57:21"
//    ]
//);

//NarociloDB::delete(
//    [
//        "id" => "1"
//    ]
//);

//NarociloDB::get(
//    [
//        "id" => "3"
//    ]
//);

NarociloDB::getAll();

