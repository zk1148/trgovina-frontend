<?php
require 'model/OcenaIzdelkaDB.php';

//OcenaIzdelkaDB::insert(["idUporabnik"=>1,"idIzdelek"=>1,"ocena"=>5]);
var_dump(OcenaIzdelkaDB::getAll());