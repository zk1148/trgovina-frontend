<?php
require 'model/PostavkaNarocilaDB.php';

//PostavkaNarocilaDB::insert(
//    [
//        "idNarocilo" => "4", "idIzdelek" => "1", "kolicina" => "12"
//    ]
//);

//PostavkaNarocilaDB::update(
//    [
//        "idNarocilo" => "4", "idIzdelek" => "1", "kolicina" => "3"
//    ]
//);

//PostavkaNarocilaDB::delete(
//    [
//        "idNarocilo" => "4", "idIzdelek" => "1"
//    ]
//);

//PostavkaNarocilaDB::get(
//    [
//        "idNarocilo" => "3", "idIzdelek" => "1"
//    ]
//);

PostavkaNarocilaDB::getAll();
